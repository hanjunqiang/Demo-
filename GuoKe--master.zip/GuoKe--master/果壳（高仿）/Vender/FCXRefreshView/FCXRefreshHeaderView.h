//
//  FCXRefreshHeaderView.h
//  RefreshPrj
//
//  Created by fcx on 15/8/21.
//  Copyright (c) 2015年 fcx. All rights reserved.
//

#import "FCXRefreshBaseView.h"

@interface FCXRefreshHeaderView : FCXRefreshBaseView

+ (instancetype)headerWithRefreshHandler:(FCXRefreshedHandler)refreshHandler;

@end
