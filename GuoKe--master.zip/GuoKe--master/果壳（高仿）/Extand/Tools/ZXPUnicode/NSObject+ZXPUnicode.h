//
//  NSObject+ZXPUnicode.h
//  House
//  blog : http://blog.csdn.net/biggercoffee
//  github : https://github.com/biggercoffee/ZXPUnicode
//  Created by coffee on 15/9/28.
//  Copyright © 2015年 cylkj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (ZXPUnicode)

+ (NSString *)stringByReplaceUnicode:(NSString *)string;

@end
