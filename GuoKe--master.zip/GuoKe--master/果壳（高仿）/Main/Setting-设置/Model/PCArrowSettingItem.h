//
//  PCArrowSettingItem.h
//  PCGuokrChoice
//
//  Created by pczhu on 16/6/19.
//  Copyright © 2016年 pc. All rights reserved.
//

#import "PCSettingItem.h"

@interface PCArrowSettingItem : PCSettingItem

// 跳转的控制器
@property (nonatomic, assign) Class destVc;

@end
