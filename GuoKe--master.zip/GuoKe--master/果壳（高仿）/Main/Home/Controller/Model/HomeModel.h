//
//  HomeModel.h
//  果壳（高仿）
//
//  Created by 张碧辉 on 16/9/17.
//  Copyright © 2016年 张碧辉. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeModel : NSObject

@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *headline_img_tb;
@property (nonatomic,copy) NSString *link_v2;

@end
/*
 {
 author = "红色皇后";
 category = health;
 "date_created" = 1469428342;
 "date_picked" = 1469491200;
 "headline_img" = "http://2.im.guokr.com/qk7K4J-x9MplCMrIegv4BQoNgR1qsIwwKBHI4YxrsswbAgAAHAEAAFBO.png";
 "headline_img_tb" = "http://2.im.guokr.com/qk7K4J-x9MplCMrIegv4BQoNgR1qsIwwKBHI4YxrsswbAgAAHAEAAFBO.png?imageView2/1/w/288/h/151";
 id = 19647;
 images =             (
 "http://3.im.guokr.com/fn4w-7oWwXq2WaTSb21OALH2Iag028ecsQPsoYBKA0T4AQAAOAAAAEpQ.jpg?imageView2/1/w/480/h/53",
 "http://1.im.guokr.com/UxKWwkqdxbu7S9GDLSHqFVBuRVoEPjxs4O9mo4bJvyB8AgAAOAAAAEpQ.jpg?imageView2/1/w/605/h/53",
 "http://3.im.guokr.com/Gk4ShBt541UiuSbk525zWbMRoRf3EjMi5dFUOzOsg6gqAQAAzQEAAEpQ.jpg",
 "http://3.im.guokr.com/hEtNox36aYqPthSzQJObWvuLZoDAcRAXQ7XYbEvKV0uHAQAAtwEAAEpQ.jpg"
 );
 "is_top" = 0;
 link = "http://jingxuan.guokr.com/pick/19647/";
 "link_v2" = "http://jingxuan.guokr.com/pick/v2/19647/";
 "link_v2_sync_img" = "http://jingxuan.guokr.com/pick/v2/19647/sync/";
 "page_source" = "http://jingxuan.guokr.com/pick/19647/?ad=1";
 "replies_count" = 0;
 "reply_root_id" = 852040;
 source = ask;
 "source_data" =             {
 id = 8;
 image = "http://3.im.guokr.com/4XeGo5F7zvRe23ZcSEtsXbetbAwkaoqItXudNKBk8z2WAQAAlgEAAEpQ.jpg";
 summary = "小黄人没有肩膀怎么穿背带裤？仰卧起坐没人压着就起不来？狗狗有没有报复心？啄木鸟会不会头晕？ 最奇怪的问题，也能在这儿找到答案！";
 title = "果壳问答";
 };
 "source_name" = "果壳问答";
 style = article;
 summary = "我找了两篇论文，先说结论，野生的熊经常有牙病。但是蛀牙并不多。 首先是1978年发表的一项研究。他们";
 title = "野生的熊会蛀牙吗？";
 "video_duration" = "<null>";
 "video_url" = "";
 },
 */
