//
//  VECollectionViewLayout.h
//  VE
//
//  Created by XianJing on 13-6-25.
//  Copyright (c) 2013年 Sikai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VECollectionViewLayout : UICollectionViewFlowLayout

@end
