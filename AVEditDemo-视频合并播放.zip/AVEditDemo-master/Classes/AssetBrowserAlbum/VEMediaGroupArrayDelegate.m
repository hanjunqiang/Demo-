//
//  VEMediaGroupArrayDelegate.m
//  VE
//
//  Created by Xuyao Tang on 13-7-1.
//  Copyright (c) 2013年 Sikai. All rights reserved.
//

#import "VEMediaGroupArrayDelegate.h"

@implementation VEMediaGroupArrayDelegate

- (void) onRefreshGroupList: (NSArray*)groups {
    
}


- (void) onFailure: (NSError*) error {
    
}

@end
