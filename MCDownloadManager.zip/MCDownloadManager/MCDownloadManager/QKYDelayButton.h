//
//  QKYDelayButton.h
//  qikeyun
//
//  Created by 马超 on 16/6/4.
//  Copyright © 2016年 Jerome. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QKYDelayButton : UIButton

@property (nonatomic,assign)NSTimeInterval clickDurationTime;

@end
