//
//  User.m
//  RealmDemo
//
//  Created by haigui on 16/7/2.
//  Copyright © 2016年 com.luohaifang. All rights reserved.
//

#import "User.h"

@implementation User

MJExtensionCodingImplementation

+ (NSString*)primaryKey {
    return @"userNo";
}

@end
