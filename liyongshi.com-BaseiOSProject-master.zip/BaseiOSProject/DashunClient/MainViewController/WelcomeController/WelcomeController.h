//
//  WelcomeController.h
//  DashunClient
//
//  Created by lottak_mac2 on 16/9/27.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeController : UIViewController

@end
