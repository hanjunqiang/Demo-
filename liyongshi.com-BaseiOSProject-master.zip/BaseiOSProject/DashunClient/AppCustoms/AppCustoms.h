//
//  AppCustoms.h
//  RealmDemo
//
//  Created by haigui on 16/7/2.
//  Copyright © 2016年 com.luohaifang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DataCache.h"

@interface AppCustoms : NSObject

+ (AppCustoms *)customs;

@end
