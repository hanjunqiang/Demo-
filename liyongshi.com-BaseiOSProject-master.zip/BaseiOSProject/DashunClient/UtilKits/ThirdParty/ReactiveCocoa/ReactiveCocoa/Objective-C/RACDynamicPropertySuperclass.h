//  Copyright (c) 2015 GitHub. All rights reserved.

#import <Foundation/Foundation.h>

/// This superclass is an implementation detail of DynamicProperty. Do
/// not use it.
@interface RACDynamicPropertySuperclass : NSObject
@end
