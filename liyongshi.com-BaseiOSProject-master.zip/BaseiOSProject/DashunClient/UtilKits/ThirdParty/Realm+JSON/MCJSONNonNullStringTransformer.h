//
//  MCJSONNonNullStringTransformer.h
//  Pods
//
//  Created by Matthew Cheok on 23/5/15.
//
//

#import <Foundation/Foundation.h>

@interface MCJSONNonNullStringTransformer : NSValueTransformer

+ (instancetype)valueTransformer;

@end
