# BaseiOSProject
一个iOS通用的基础工程，下载下来直接以此开始你的项目（偷师于5年iOS经验上司）
