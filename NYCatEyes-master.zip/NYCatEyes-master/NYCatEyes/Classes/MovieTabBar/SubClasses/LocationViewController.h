//
//  LocationViewController.h
//  NYCatEyes
//
//  Created by 牛严 on 15/10/9.
//  Copyright (c) 2015年 牛严. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface LocationViewController : BaseViewController

@end
