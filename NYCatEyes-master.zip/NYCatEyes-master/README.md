# NYCatEyes
## 仿猫眼电影APP框架，tabbar下navigationcontroller框架。NavigationBar中间添加滑动点击导航，childviewcontroller。

![pic1](https://raw.githubusercontent.com/lfny2580832/NYCatEyes/master/ScreenShots/NYCatEyes.gif)
![pic2](https://raw.githubusercontent.com/lfny2580832/NYCatEyes/master/ScreenShots/NoAnimation.gif)
