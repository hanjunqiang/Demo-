//
//  LTopPelletManager.h
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LPelletView.h"
//顶部队列管理器
@interface LTopPelletManager : NSObject

- (instancetype)initWithPelletView:(LPelletView*)lPelletView;

- (void)addMessage:(LPelletMessage*)lPelletMessage;

@end
