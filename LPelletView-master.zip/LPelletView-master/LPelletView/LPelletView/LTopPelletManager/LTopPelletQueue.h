//
//  LTopPelletQueue.h
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LPelletMessage.h"
//顶部弹雾队列，由一个数组进行管理
@interface LTopPelletQueue : UIView
//本队列已经有多少秒时间未显示 用来计算最佳的显示队列
@property (nonatomic, assign) int afterAllShowTime;

- (instancetype)initWith:(CGRect)frame messageMaxWidth:(CGFloat)maxWidth;

- (void)addMessage:(LPelletMessage*)lPelletMessage;

@end
