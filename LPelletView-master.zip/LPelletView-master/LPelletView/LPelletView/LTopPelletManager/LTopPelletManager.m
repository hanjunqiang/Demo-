//
//  LTopPelletManager.m
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LTopPelletManager.h"
#import "LTopPelletQueue.h"

@interface LTopPelletManager () {
    LPelletView *_lPelletView;//弹雾视图，用来操作
    NSMutableArray<LTopPelletQueue*> *_lTopPelletQueueArr;//队列
}

@end

@implementation LTopPelletManager

- (instancetype)initWithPelletView:(LPelletView*)lPelletView {
    if(self = [super init]) {
        _lPelletView = lPelletView;
        _lTopPelletQueueArr = [@[] mutableCopy];
        //创建消息队列
        for (CGFloat pointX = 0; pointX < lPelletView.frame.size.height / 2.f; pointX += _lPelletView.messageHeight) {
            LTopPelletQueue *queue = [[LTopPelletQueue alloc] initWith:CGRectMake(0, pointX, lPelletView.frame.size.width, _lPelletView.messageHeight) messageMaxWidth:_lPelletView.maxMessageWidth];
            [lPelletView addSubview:queue];
            [_lTopPelletQueueArr addObject:queue];
        }
    }
    return self;
}
- (void)addMessage:(LPelletMessage*)lPelletMessage {
    //这里算出最适合显示的队列
    int minTime = [_lTopPelletQueueArr[0] afterAllShowTime];
    LTopPelletQueue *minQueue = _lTopPelletQueueArr[0];
    for (int i = 1; i < _lTopPelletQueueArr.count; i ++) {
        if([_lTopPelletQueueArr[i] afterAllShowTime] < minTime) {
            minTime = [_lTopPelletQueueArr[i] afterAllShowTime];
            minQueue = _lTopPelletQueueArr[i];
        }
    }
    [minQueue addMessage:lPelletMessage];
}

@end
