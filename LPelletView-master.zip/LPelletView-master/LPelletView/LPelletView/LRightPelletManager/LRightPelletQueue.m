//
//  LRightPelletQueue.m
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LRightPelletQueue.h"

@interface LRightPelletQueue () {
    NSTimer *_nSTimer;
    NSMutableArray<LPelletMessage*> *_lPelletMessageArr;//这里存放将要显示的消息
}
//多少S过后本队列可用
@property (nonatomic, assign) int afterEffective;
//文字最长宽度
@property (nonatomic, assign) CGFloat messageMaxWidth;

@end

@implementation LRightPelletQueue

- (instancetype)initWith:(CGRect)frame messageMaxWidth:(CGFloat)maxWidth {
    if(self = [super initWithFrame:frame]) {
        self.messageMaxWidth = maxWidth;
        _nSTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerClkcied:) userInfo:nil repeats:YES];
        [_nSTimer setFireDate:[NSDate distantFuture]];
        _lPelletMessageArr = [@[] mutableCopy];
    }
    return self;
}
- (void)timerClkcied:(NSTimer*)timer {
    self.afterEffective --;
    self.afterAllShowTime --;
    //当前消息显示完毕
    if(self.afterEffective == 0) {
        //队列中是否有需要显示的
        if(_lPelletMessageArr.count != 0) {
            LPelletMessage *lPelletMessage = _lPelletMessageArr[0];
            //显示当前消息  启动定时器
            CGFloat width = [self textSizeWithStr:lPelletMessage.message font:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(_messageMaxWidth, self.frame.size.height)].width;
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.width, 0, width, self.frame.size.height)];
            label.textColor = lPelletMessage.color;
            label.text = lPelletMessage.message;
            [self addSubview:label];
            //算出移动出屏幕需要多少时间
            CGFloat timeMove = (self.frame.size.width + width) / lPelletMessage.moveSpeed;
            [UIView animateWithDuration:timeMove animations:^{
                label.frame = CGRectMake(-width, 0, width, self.frame.size.height);
            } completion:^(BOOL finished) {
                [label removeFromSuperview];
            }];
            self.afterEffective = width / lPelletMessage.moveSpeed + 1;
            [_lPelletMessageArr removeObjectAtIndex:0];
        } else {
            [_nSTimer setFireDate:[NSDate distantFuture]];
        }
    }
}
- (void)addMessage:(LPelletMessage*)lPelletMessage {
    //是不是正在显示一条消息
    if(self.afterEffective != 0) {
        [_lPelletMessageArr addObject:lPelletMessage];
        return;
    }
    //显示当前消息  启动定时器
    CGFloat width = [self textSizeWithStr:lPelletMessage.message font:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(_messageMaxWidth, self.frame.size.height)].width;
    if(width > self.messageMaxWidth)
        width = self.messageMaxWidth;
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.width, 0, width, self.frame.size.height)];
    label.textColor = lPelletMessage.color;
    label.text = lPelletMessage.message;
    label.adjustsFontSizeToFitWidth = YES;
    [self addSubview:label];
    //算出移动出屏幕需要多少时间
    CGFloat timeMove = (self.frame.size.width + width) / lPelletMessage.moveSpeed;
    [UIView animateWithDuration:timeMove animations:^{
        label.frame = CGRectMake(-width, 0, width, self.frame.size.height);
    } completion:^(BOOL finished) {
        [label removeFromSuperview];
    }];
    self.afterEffective = width / lPelletMessage.moveSpeed + 1;
    //将要显示的时间加上新的时间
    self.afterAllShowTime += self.afterEffective;
    [_nSTimer setFireDate:[NSDate distantPast]];
}
- (CGSize)textSizeWithStr:(NSString*)str font:(UIFont *)font constrainedToSize:(CGSize)size
{
    CGSize textSize;
    if (CGSizeEqualToSize(size, CGSizeZero)) {
        NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:NSFontAttributeName];
        textSize = [str sizeWithAttributes:attributes];
    } else {
        NSStringDrawingOptions option = NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
        NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:NSFontAttributeName];
        CGRect rect = [str boundingRectWithSize:size options:option attributes:attributes context:nil];
        textSize = rect.size;
    }
    return textSize;
}

@end
