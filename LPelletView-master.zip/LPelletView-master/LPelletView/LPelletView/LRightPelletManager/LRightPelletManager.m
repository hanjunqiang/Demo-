//
//  LRightPelletManager.m
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LRightPelletManager.h"
#import "LRightPelletQueue.h"

@interface LRightPelletManager (){
    LPelletView *_lPelletView;//弹雾视图，用来操作
    NSMutableArray<LRightPelletQueue*> *_lTopPelletQueueArr;//队列
}

@end

@implementation LRightPelletManager

- (instancetype)initWithPelletView:(LPelletView*)lPelletView {
    if(self = [super init]) {
        _lPelletView = lPelletView;
        _lTopPelletQueueArr = [@[] mutableCopy];
        //创建消息队列
        for (CGFloat pointX = 0; pointX < lPelletView.frame.size.height; pointX += _lPelletView.messageHeight) {
            LRightPelletQueue *queue = [[LRightPelletQueue alloc] initWith:CGRectMake(0, pointX, lPelletView.frame.size.width, _lPelletView.messageHeight) messageMaxWidth:_lPelletView.maxMessageWidth];
            [lPelletView addSubview:queue];
            [_lTopPelletQueueArr addObject:queue];
        }
    }
    return self;
}
- (void)addMessage:(LPelletMessage*)lPelletMessage {
    //这里算出最适合显示的队列
    int minTime = [_lTopPelletQueueArr[0] afterAllShowTime];
    LRightPelletQueue *minQueue = _lTopPelletQueueArr[0];
    for (int i = 1; i < _lTopPelletQueueArr.count; i ++) {
        if([_lTopPelletQueueArr[i] afterAllShowTime] < minTime) {
            minTime = [_lTopPelletQueueArr[i] afterAllShowTime];
            minQueue = _lTopPelletQueueArr[i];
        }
    }
    [minQueue addMessage:lPelletMessage];
}
@end
