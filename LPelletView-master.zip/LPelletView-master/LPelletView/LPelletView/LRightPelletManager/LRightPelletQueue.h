//
//  LRightPelletQueue.h
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LPelletMessage.h"

@interface LRightPelletQueue : UIView
//本队列已经有多少秒时间未显示 用来计算最佳的显示队列
@property (nonatomic, assign) int afterAllShowTime;

- (instancetype)initWith:(CGRect)frame messageMaxWidth:(CGFloat)maxWidth;

- (void)addMessage:(LPelletMessage*)lPelletMessage;

@end
