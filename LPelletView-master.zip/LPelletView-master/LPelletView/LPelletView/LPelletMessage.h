//
//  LPelletMessage.h
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger, LPelletMessageType) {
    LPelletMessageType_From_Top,//顶部向下
    LPelletMessageType_From_Bottom,//底部向上
    LPelletMessageType_From_Right//右边向左边
};
//消息对象
@interface LPelletMessage : NSObject

//发送者提供
@property (nonatomic, strong) NSString *message;//发送的内容
@property (nonatomic, strong) UIColor *color;//字体颜色
@property (nonatomic, assign) LPelletMessageType lPelletMessageType;//发送的位置

//管理器创建
@property (nonatomic, assign) int sendTime;//发送时间
@property (nonatomic, assign) int showTime;//要显示的时间（占用队列的时间）
@property (nonatomic, assign) CGFloat moveSpeed;//移动的速度

@end
