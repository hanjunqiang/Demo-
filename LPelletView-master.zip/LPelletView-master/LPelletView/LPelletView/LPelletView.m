//
//  LPelletView.m
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LPelletView.h"
#import "LTopPelletManager.h"
#import "LBottomPelletManager.h"
#import "LRightPelletManager.h"

@interface LPelletView () {
    LTopPelletManager *_lTopPelletManager;
    LBottomPelletManager *_lBottomPelletManager;
    LRightPelletManager *_lRightPelletManager;
    NSTimer *_nSTimer;
    int _timer;
}

@end

@implementation LPelletView

- (instancetype)initWith:(CGRect)frame messageHeight:(CGFloat)height messageMaxWidth:(CGFloat)maxWidth {
    self = [super initWithFrame:frame];
    if (self) {
        _messageHeight = height;
        _maxMessageWidth = maxWidth;
        _timer = 0;
        _nSTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerClicked:) userInfo:nil repeats:YES];
        _lTopPelletManager = [[LTopPelletManager alloc] initWithPelletView:self];
        _lBottomPelletManager = [[LBottomPelletManager alloc] initWithPelletView:self];
        _lRightPelletManager = [[LRightPelletManager alloc] initWithPelletView:self];
    }
    return self;
}
- (void)timerClicked:(NSTimer*)timer {
    _timer ++;
}
//分发处理消息
- (void)sendMessage:(LPelletMessage*)lPelletMessage {
    lPelletMessage.sendTime = _timer;
    switch (lPelletMessage.lPelletMessageType) {
        case LPelletMessageType_From_Top:
            lPelletMessage.showTime = 2 + arc4random() % 3;//顶部默认都显示2秒后消失
            [_lTopPelletManager addMessage:lPelletMessage];
            break;
        case LPelletMessageType_From_Bottom:
            lPelletMessage.showTime = 2 + arc4random() % 3;//顶部默认都显示2秒后消失
            [_lBottomPelletManager addMessage:lPelletMessage];
            break;
        case LPelletMessageType_From_Right:
            lPelletMessage.moveSpeed = 60 + arc4random() % 40;//移动的速度随机取得
            [_lRightPelletManager addMessage:lPelletMessage];
            break;
        default:
            break;
    }
}

@end
