//
//  LBottomPelletQueue.m
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LBottomPelletQueue.h"

@interface LBottomPelletQueue () {
    NSTimer *_nSTimer;
    NSMutableArray<LPelletMessage*> *_lPelletMessageArr;//这里存放将要显示的消息
}
//多少S过后本队列可用
@property (nonatomic, assign) int afterEffective;
//用于显示内容的标签
@property (nonatomic, strong) UILabel *messageLabel;


@end

@implementation LBottomPelletQueue

- (instancetype)initWith:(CGRect)frame messageMaxWidth:(CGFloat)maxWidth {
    if(self = [super initWithFrame:frame]) {
        self.messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.5 * (frame.size.width - maxWidth), 0, maxWidth, frame.size.height)];
        self.messageLabel.textAlignment = NSTextAlignmentCenter;
        self.messageLabel.adjustsFontSizeToFitWidth = YES;
        [self addSubview:self.messageLabel];
        _nSTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerClkcied:) userInfo:nil repeats:YES];
        [_nSTimer setFireDate:[NSDate distantFuture]];
        _lPelletMessageArr = [@[] mutableCopy];
    }
    return self;
}
- (void)timerClkcied:(NSTimer*)timer {
    self.afterEffective --;
    self.afterAllShowTime --;
    //当前消息显示完毕
    if(self.afterEffective == 0) {
        //队列中是否有需要显示的
        if(_lPelletMessageArr.count != 0) {
            self.afterEffective = [_lPelletMessageArr[0] showTime];
            self.messageLabel.text = [_lPelletMessageArr[0] message];
            self.messageLabel.textColor = [_lPelletMessageArr[0] color];
            [_lPelletMessageArr removeObjectAtIndex:0];
        } else {
            self.messageLabel.text = @"";
            [_nSTimer setFireDate:[NSDate distantFuture]];
        }
    }
}
- (void)addMessage:(LPelletMessage*)lPelletMessage {
    //将要显示的时间加上新的时间
    self.afterAllShowTime += lPelletMessage.showTime;
    //是不是正在显示一条消息
    if(self.afterEffective != 0) {
        [_lPelletMessageArr addObject:lPelletMessage];
        return;
    }
    //显示当前消息  启动定时器
    self.messageLabel.text = lPelletMessage.message;
    self.messageLabel.textColor = lPelletMessage.color;
    self.afterEffective = lPelletMessage.showTime;
    [_nSTimer setFireDate:[NSDate distantPast]];
}
@end
