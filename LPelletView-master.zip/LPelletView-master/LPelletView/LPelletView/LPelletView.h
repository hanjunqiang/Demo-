//
//  LPelletView.h
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LPelletMessage.h"
//弹雾视图
@interface LPelletView : UIView
//消息显示的高度
@property (nonatomic, assign) CGFloat messageHeight;
//消息显示的最长宽度
@property (nonatomic, assign) CGFloat maxMessageWidth;

- (instancetype)initWith:(CGRect)frame messageHeight:(CGFloat)height messageMaxWidth:(CGFloat)maxWidth;

- (void)sendMessage:(LPelletMessage*)lPelletMessage;

@end
