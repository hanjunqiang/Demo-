//
//  ViewController.m
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "ViewController.h"
#import "LPelletView.h"
#import "LPelletPersonModel.h"
//使用方法 创建一个用户 用用户来发送消息
@interface ViewController () {
    LPelletView *_lPelletView;
    LPelletPersonModel *_lPelletPerson;
    LPelletMessageType _lPelletMessageType;
}

@property (weak, nonatomic) IBOutlet UIButton *messageType;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UITextField *messageField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建一个用户
    _lPelletPerson = [LPelletPersonModel new];
    _lPelletPerson.vipGrade = 5;
    _lPelletPerson.name = @"Fuck You!";
    _lPelletMessageType = LPelletMessageType_From_Right;
    [self.messageType setTitle:@"右侧" forState:UIControlStateNormal];
    //创建弹雾视图
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    _lPelletView = [[LPelletView alloc] initWith:CGRectMake(0, 0, width - 10, 200) messageHeight:20 messageMaxWidth:width - 50];
    [self.imageView addSubview:_lPelletView];
    
}
- (IBAction)messageTyper:(id)sender {
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"选择类型" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancle = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *top = [UIAlertAction actionWithTitle:@"顶部" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        _lPelletMessageType = LPelletMessageType_From_Top;
    }];
    UIAlertAction *bottom = [UIAlertAction actionWithTitle:@"底部" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        _lPelletMessageType = LPelletMessageType_From_Bottom;
    }];
    UIAlertAction *right = [UIAlertAction actionWithTitle:@"右侧" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        _lPelletMessageType = LPelletMessageType_From_Right;
    }];
    [alertVC addAction:right];
    [alertVC addAction:top];
    [alertVC addAction:bottom];
    [alertVC addAction:cancle];
    [self presentViewController:alertVC animated:YES completion:nil];
}
- (IBAction)sendMessage:(id)sender {
    [self.view endEditing:YES];
    LPelletMessage *message = [_lPelletPerson createLPelletMessage:self.messageField.text lPelletMessageType:_lPelletMessageType];
    [_lPelletView sendMessage:message];
}

@end
