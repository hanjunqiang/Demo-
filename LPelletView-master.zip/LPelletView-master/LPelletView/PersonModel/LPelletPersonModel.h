//
//  LPelletPersonModel.h
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LPelletMessage.h"
//弹雾发送者
@interface LPelletPersonModel : NSObject

@property (nonatomic, assign) int vipGrade;//VIP等级
@property (nonatomic, strong) NSString *name;//发送者名字

- (LPelletMessage*)createLPelletMessage:(NSString*)message lPelletMessageType:(LPelletMessageType)lPelletMessageType;

@end
