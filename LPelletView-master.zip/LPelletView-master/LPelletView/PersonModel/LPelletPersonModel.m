//
//  LPelletPersonModel.m
//  LPelletView
//
//  Created by lottak_mac2 on 16/9/5.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "LPelletPersonModel.h"

@implementation LPelletPersonModel

- (LPelletMessage*)createLPelletMessage:(NSString*)message lPelletMessageType:(LPelletMessageType)lPelletMessageType {
    LPelletMessage *lPelletMessage = [LPelletMessage new];
    lPelletMessage.message = message;
    lPelletMessage.lPelletMessageType = lPelletMessageType;
    lPelletMessage.color = [self getColor];
    return lPelletMessage;
}
//颜色根据发送者的VIP等级确定
- (UIColor*)getColor {
    UIColor *color = nil;
    switch (self.vipGrade) {
        case 1: color = [UIColor blackColor]; break;
        case 2: color = [UIColor blackColor]; break;
        case 3: color = [UIColor blackColor]; break;
        case 4: color = [UIColor blueColor]; break;
        case 5: color = [UIColor orangeColor]; break;
        case 6: color = [UIColor yellowColor]; break;
        case 7: color = [UIColor redColor]; break;
        default: break;
    }
    return color;
}
@end
