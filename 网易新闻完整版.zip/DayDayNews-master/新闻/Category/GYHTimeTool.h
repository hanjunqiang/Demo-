//
//  GYHTimeTool.h
//  testhuanxin
//
//  Created by gyh on 16/5/6.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GYHTimeTool : NSObject
/**
 *  时间戳返回时间
 */
+(NSString *)timeStr:(long long)timestamp;

@end
