//
//  GYHHeadeRefreshController.h
//  新闻
//
//  Created by gyh on 16/3/3.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "MJRefreshGifHeader.h"

@interface GYHHeadeRefreshController :MJRefreshGifHeader

@end
