//
//  ViewController.m
//  SelectAttachment
//
//  Created by lottak_mac2 on 16/8/11.
//  Copyright © 2016年 com.lottak. All rights reserved.
//

#import "ViewController.h"
#import "SelectAttachmentController.h"

@interface ViewController ()<SelectAttachmentDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
#pragma mark -- SelectAttachmentDelegate
//选择成功
- (void)selectAttachmentFinish:(NSMutableArray<Attachment*>*)attachmentArr {
    
}
//选择成功
- (void)selectAttachmentCancel {
    
}
- (IBAction)selectAttachment:(id)sender {
    SelectAttachmentController * selectAttachmentController =[SelectAttachmentController new];
    selectAttachmentController.maxSelect = 9;
    selectAttachmentController.delegate = self;
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:selectAttachmentController] animated:YES completion:nil];
}

@end
