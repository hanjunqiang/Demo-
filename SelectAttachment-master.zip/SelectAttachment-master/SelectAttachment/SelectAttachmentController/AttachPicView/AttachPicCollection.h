//
//  AttachPicCollection.h
//  RealmDemo
//
//  Created by lottak_mac2 on 16/8/9.
//  Copyright © 2016年 com.luohaifang. All rights reserved.
//

#import <UIKit/UIKit.h>
//相册中表格视图CELL中的集合视图CELL
@interface AttachPicCollection : UICollectionViewCell

@end
