# NYTubeAnimation
页面切换指示动画

动画解析教程：http://www.jianshu.com/p/8a569dfd1c4b
效果图：


![gif](https://github.com/lfny2580832/NYTubeAnimation/blob/master/demo.gif)

分解图：


![分解图](https://github.com/lfny2580832/NYTubeAnimation/blob/master/分解图.png)
