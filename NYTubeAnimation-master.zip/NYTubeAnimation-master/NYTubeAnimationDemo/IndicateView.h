//
//  IndicateView.h
//  NYTubeAnimationDemo
//
//  Created by 牛严 on 2016/10/8.
//  Copyright © 2016年 牛严. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndicateView : UIView


- (void)turnToSecondPage;
- (void)turnToFirstPage;

- (void)setDelegate:(id)delegate;

@end
