//
//  MultipleViewController.h
//  TCBlobDownloadExample
//
//  Created by Albert on 27.04.14.
//  Copyright (c) 2014 thibaultCha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TCBlobDownload/TCBlobDownload.h>

@interface MultipleViewController : UITableViewController <UIAlertViewDelegate, TCBlobDownloaderDelegate>

@end
