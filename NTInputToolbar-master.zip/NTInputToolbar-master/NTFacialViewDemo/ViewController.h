//
//  ViewController.h
//  NTFacialViewDemo
//
//  Created by nonstriater on 14-4-12.
//  Copyright (c) 2014年 xiaoran. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
