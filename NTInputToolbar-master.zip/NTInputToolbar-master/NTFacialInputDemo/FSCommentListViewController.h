//
//  FSCommentListViewController.h
//  FuShuo
//
//  Created by nonstriater on 14-4-10.
//  Copyright (c) 2014年 xiaoran. All rights reserved.
//


@interface FSCommentListViewController : UITableViewController

@property (nonatomic,strong) NSArray *dataItems;

@end
