//
//  AppDelegate.h
//  NTFacialInputDemo
//
//  Created by nonstriater on 14-4-12.
//  Copyright (c) 2014年 xiaoran. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
